CREATE TABLE public.bookings (
  id BIGSERIAL PRIMARY KEY,
  booking_id VARCHAR(24) NOT NULL UNIQUE,
  name VARCHAR(60) NOT NULL,
  phone VARCHAR(10) NOT NULL,
  service VARCHAR(20) NOT NULL,
  speed VARCHAR(10) NOT NULL,
  handover VARCHAR(10) NOT NULL,
  address TEXT,
  booking_date DATE NOT NULL,
  slot VARCHAR(30) NOT NULL,
  bill VARCHAR(12) NOT NULL,
  notes VARCHAR(200),
  first_order BOOLEAN NOT NULL DEFAULT false,
  discount_percent INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'new' CHECK (status IN ('new','confirmed','picked_up','in_process','ready','delivered','cancelled')),
  whatsapp_owner BOOLEAN NOT NULL DEFAULT false,
  whatsapp_customer BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.bookings TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.bookings_id_seq TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE INDEX ix_bookings_phone ON public.bookings (phone);
CREATE INDEX ix_bookings_booking_date ON public.bookings (booking_date);
CREATE INDEX ix_bookings_status ON public.bookings (status);
CREATE INDEX ix_bookings_created_at ON public.bookings (created_at);