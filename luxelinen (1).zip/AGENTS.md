<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- The public site is the original static HTML (src/site/body.html) and CSS (src/site/luxe.css) rendered on `/`, with its script ported to src/site/luxe-site.ts; keep the markup ids in sync with that script.
- Bookings are written only by server functions in src/lib/bookings.functions.ts using the admin client; the bookings table has RLS on with no public policies, so browsers never touch it directly.
- The shop view at /admin is gated by the ADMIN_KEY secret checked server-side (kept from the original x-admin-key design).
- Billing is stored with each booking; server-side billing rules calculate totals from regular item rates, booking speed and saved discount, so client totals cannot be trusted.
- Walk-in orders use client-generated UUID references and server-side idempotent creation; offline bill drafts are stored on the current device and synced manually after shop-key verification, preventing duplicate orders on retries.
- Offline app-shell caching uses vite-plugin-pwa with a single preview-guarded registrar, NetworkFirst admin navigations and no RPC caching; cached order data stays in the tab session and locking clears it.
