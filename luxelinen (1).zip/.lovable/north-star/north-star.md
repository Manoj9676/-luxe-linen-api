<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Customers get the Luxe Linen service they want, at a time that suits them.

## Metric

Bookings placed each week
