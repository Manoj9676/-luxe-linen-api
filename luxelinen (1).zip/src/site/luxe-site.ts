// @ts-nocheck
// Interactive behaviour of the Luxe Linen page, ported from the original js/main.js.
export function initLuxeSite(api){

var $=function(s){return document.querySelector(s)};
// menu
var mb=$('.menu'),ln=$('#links');
mb.onclick=function(){var o=ln.classList.toggle('open');mb.setAttribute('aria-expanded',o)};
ln.addEventListener('click',function(e){if(e.target.tagName==='A'){ln.classList.remove('open');mb.setAttribute('aria-expanded',false)}});
// open now (India time)
var ist=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'}));
var d=ist.getDay(),mins=ist.getHours()*60+ist.getMinutes(),msg,cls;
var open=d===1?null:(d===0?[660,1080]:[480,1200]);
if(!open){msg='Closed today (weekly holiday)';cls='off'}
else if(mins>=780&&mins<840){msg='Lunch break, back at 2:00 PM';cls='off'}
else if(mins>=open[0]&&mins<open[1]){msg='Open now until '+(d===0?'6 PM':'8 PM');cls='on'}
else{msg='Closed now';cls='off'}
$('#status .dot').className='dot '+cls;$('#status span:last-child').textContent=msg+' (public holidays closed)';
document.querySelectorAll('#hours tr').forEach(function(r){if(r.dataset.d.split(',').indexOf(String(d))>-1)r.className='today'});
// flip cards on tap
document.querySelectorAll('.flip').forEach(function(b){b.addEventListener('click',function(){b.classList.toggle('on')})});
// theme
var th=$('#th'),root=document.documentElement;
function applyTheme(t){if(t==='light'){root.setAttribute('data-theme','light');th.textContent='Night look'}else{root.removeAttribute('data-theme');th.textContent='Fresh look'}}
var saved=null;try{saved=localStorage.getItem('ll-theme')}catch(e){}
applyTheme(saved);
th.onclick=function(){var t=root.getAttribute('data-theme')==='light'?'dark':'light';applyTheme(t);try{localStorage.setItem('ll-theme',t)}catch(e){}};
// tile tilt
document.querySelectorAll('.tile').forEach(function(t){
t.addEventListener('pointermove',function(e){var r=t.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;t.style.transform='rotateX('+(-y*14)+'deg) rotateY('+(x*18)+'deg)'});
t.addEventListener('pointerleave',function(){t.style.transform=''})});

// click bubbles
var calm=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var onDown=function(e){
if(calm)return;
for(var i=0;i<9;i++){var s=document.createElement('span'),z=10+Math.random()*22,a=Math.random()*Math.PI*2,r=40+Math.random()*70;
s.className='fx';s.style.cssText='left:'+(e.clientX-z/2)+'px;top:'+(e.clientY-z/2)+'px;width:'+z+'px;height:'+z+'px;--dx:'+Math.cos(a)*r+'px;--dy:'+(Math.sin(a)*r-50)+'px';
document.body.appendChild(s);(function(n){setTimeout(function(){n.remove()},1400)})(s)}};document.addEventListener('pointerdown',onDown);
// hero coin click, orbs parallax, scroll depth
var hero=$('.hero'),orbs=document.querySelectorAll('.orbs span');
hero.addEventListener('pointermove',function(e){var x=e.clientX-innerWidth/2,y=e.clientY-innerHeight/2;orbs.forEach(function(o){var d=+o.dataset.d;o.style.transform='translate3d('+(-x*d)+'px,'+(-y*d)+'px,0)'})});
// tile click spin
document.querySelectorAll('.tile').forEach(function(t){t.addEventListener('click',function(){t.classList.remove('spin');void t.offsetWidth;t.classList.add('spin')});t.addEventListener('animationend',function(){t.classList.remove('spin')})});
// services coverflow
var cw=$('#cw'),cards=[].slice.call(cw.querySelectorAll('.cc')),N=cards.length,cur=0,names=['Laundry: wash, dry and fold.','Dryclean: gentle care for suits, sarees and silks.','Ironing: crisp steam-pressed finish.','Home linen: fresh sheets and towels.','Curtains: premium drapes cleaned with care.','Express: ask for it when you need clothes fast.'],drag=null,moved=false;
function lay(){var step=Math.min(190,cw.clientWidth*.3),h=Math.floor(N/2);cards.forEach(function(el,i){var d=((i-cur)%N+N+h)%N-h,a=Math.abs(d);
el.style.transform='translateX('+d*step+'px) translateZ('+(-a*110)+'px) rotateY('+(-d*32)+'deg) scale('+(a?0.88:1)+')';
el.style.opacity=a>2?0:(a?.75:1);el.style.zIndex=10-a;el.style.pointerEvents=a>2?'none':'auto';el.classList.toggle('on',a===0)});$('#cnote').textContent=names[cur]}
function show(i){cur=(i%N+N)%N;lay()}
cards.forEach(function(el,i){el.addEventListener('click',function(){if(!moved)show(i)})});
cw.addEventListener('pointerdown',function(e){drag=e.clientX;moved=false});
window.addEventListener('pointermove',function(e){if(drag!==null&&Math.abs(e.clientX-drag)>8)moved=true});
window.addEventListener('pointerup',function(e){if(drag===null)return;var dx=e.clientX-drag;drag=null;if(Math.abs(dx)>40)show(cur+(dx<0?1:-1));setTimeout(function(){moved=false},0)});
$('#cn').onclick=function(){show(cur+1)};$('#cp').onclick=function(){show(cur-1)};
window.addEventListener('resize',lay);lay();
// reveal
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.15});
document.querySelectorAll('.reveal').forEach(function(el){io.observe(el)});
// booking
var API=true;
var WEEK=['9 AM to 12 PM','2 PM to 5 PM','5 PM to 8 PM'],SUN=['11 AM to 1 PM','2 PM to 6 PM'];
var f=$('#f'),done=$('#done'),errBox=$('#e'),dt=$('#d'),slot=$('#t'),offer=$('#offer'),sub=$('#sub');
function pad(n){return n<10?'0'+n:''+n}
function iso(x){return x.getFullYear()+'-'+pad(x.getMonth()+1)+'-'+pad(x.getDate())}
var today=new Date(ist.getFullYear(),ist.getMonth(),ist.getDate()),maxD=new Date(today);maxD.setDate(maxD.getDate()+30);
dt.min=iso(today);dt.max=iso(maxD);
function dayOf(v){var p=v.split('-');return new Date(+p[0],+p[1]-1,+p[2]).getDay()}
function fillSlots(){slot.innerHTML='';(dt.value&&dayOf(dt.value)===0?SUN:WEEK).forEach(function(s){var o=document.createElement('option');o.textContent=s;slot.appendChild(o)})}
fillSlots();
dt.addEventListener('change',function(){errBox.textContent=dt.value&&dayOf(dt.value)===1?'We are closed on Mondays. Please choose another date.':'';fillSlots()});
$('#h').addEventListener('change',function(){$('#addrBox').hidden=this.value==='drop'});
function normPhone(v){var d=String(v).replace(/\D/g,'');if(d.length===12&&d.indexOf('91')===0)d=d.slice(2);if(d.length===11&&d[0]==='0')d=d.slice(1);return /^[6-9]\d{9}$/.test(d)?d:null}
function booked(){try{return JSON.parse(localStorage.getItem('ll-booked')||'[]')}catch(e){return[]}}
function remember(p){try{var l=booked();if(l.indexOf(p)<0){l.push(p);localStorage.setItem('ll-booked',JSON.stringify(l))}}catch(e){}}
function showOffer(first){offer.className='offer'+(first===true?' on':'');offer.textContent=first===true?'This is your first order: 30% off will be applied to your bill.':first===false?'Welcome back. Pickup and drop is free within 2 km.':'First order gets 30% off.'}
function checkFirst(p){
if(!API){showOffer(booked().indexOf(p)<0);return}
api.checkFirstOrder({data:{phone:p}}).then(function(j){showOffer(!!j.firstOrder)}).catch(function(){showOffer(null)})}
$('#p').addEventListener('input',function(){var p=normPhone(this.value);if(p)checkFirst(p);else showOffer(null)});
function fail(msg,sel){errBox.textContent=msg;$(sel).focus()}
function busy(on){sub.disabled=on;sub.textContent=on?'Booking\u2026':'Book now'}
function newId(){var a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',s='';for(var i=0;i<4;i++)s+=a[Math.floor(Math.random()*a.length)];return 'LL-'+String(ist.getFullYear()).slice(2)+pad(ist.getMonth()+1)+pad(ist.getDate())+'-'+s}
function render(r,d){
f.hidden=true;offer.hidden=true;done.hidden=false;$('#bid').textContent=r.bookingId;
var sum=$('#sum');sum.innerHTML='';
[d.service+' ('+d.speed+')',(d.handover==='pickup'?'Pickup: ':'Drop at shop: ')+d.date+', '+d.slot,d.handover==='pickup'?'Address: '+d.address:'',r.firstOrder?'First order: '+(r.discountPercent||30)+'% off on your bill':(d.speed==='Express'?'Express service is charged at double the regular price':'')].forEach(function(t){if(!t)return;var li=document.createElement('li');li.textContent=t;sum.appendChild(li)});
var wa=$('#wa');
if(r.demo)wa.textContent='Demo mode: this booking was not saved and no WhatsApp message was sent. Connect the booking server to go live.';
else if(r.whatsapp&&r.whatsapp.customer)wa.textContent='We have sent your confirmation to WhatsApp +91 '+d.phone+'.';
else wa.textContent='Your booking is saved. We could not send the WhatsApp message, so we will call you on +91 '+d.phone+' to confirm.';
done.scrollIntoView({behavior:calm?'auto':'smooth',block:'center'});done.focus({preventScroll:true})}
f.addEventListener('submit',function(e){e.preventDefault();
var nm=$('#n').value.trim(),ph=normPhone($('#p').value),mode=$('#h').value,ad=$('#a').value.trim();
if(!nm)return fail('Enter your name.','#n');
if(!ph)return fail('Enter a valid 10-digit mobile number.','#p');
if(mode==='pickup'&&ad.length<10)return fail('Enter your full address so we can reach you.','#a');
if(!dt.value)return fail('Choose a date.','#d');
if(dayOf(dt.value)===1)return fail('We are closed on Mondays. Please choose another date.','#d');
errBox.textContent='';
var d={name:nm,phone:ph,service:$('#s').value,speed:$('#sp').value,handover:mode,address:mode==='pickup'?ad:'',date:dt.value,slot:slot.value,notes:$('#m').value.trim(),website:$('#hp').value};
busy(true);
if(!API){setTimeout(function(){var first=booked().indexOf(ph)<0;remember(ph);busy(false);render({bookingId:newId(),firstOrder:first,discountPercent:30,demo:true},d)},700);return}
api.createBooking({data:d})
.then(function(j){busy(false);if(j.ok)render(j,d);else errBox.textContent=j.error||'Could not book. Please call 8790774441.'})
.catch(function(){busy(false);errBox.textContent='Could not reach the booking server. Please try again or call 8790774441.'})});
$('#again').onclick=function(){done.hidden=true;f.hidden=false;offer.hidden=false;f.reset();fillSlots();$('#addrBox').hidden=false;showOffer(null);f.scrollIntoView({block:'start'})};

return function(){document.removeEventListener('pointerdown',onDown);window.removeEventListener('resize',lay);io.disconnect()};
}
