import { createServerFn } from "@tanstack/react-start";
import { validateWalkIn, type WalkInInput } from './admin-order-rules';
import { calculateBill, validateBillingItems, PAYMENT_METHODS, type PaymentStatus } from "./billing-rules";
import {
  BOOKING_STATUSES, DISCOUNT_PERCENT, buildMessages, newBookingId, normPhone, todayIST, validate,
  type BookingStatus, type BookingInput,
} from "./booking-rules";

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function isFirstOrder(phone: string) {
  const db = await admin();
  const { count, error } = await db.from("bookings").select("id", { count: "exact", head: true }).eq("phone", phone);
  if (error) throw new Error("Database error");
  return (count ?? 0) === 0;
}

export const checkFirstOrder = createServerFn({ method: "POST" })
  .inputValidator((input: { phone: string }) => ({ phone: String(input?.phone ?? "") }))
  .handler(async ({ data }) => {
    const p = normPhone(data.phone);
    if (!p) return { ok: false as const, error: "Invalid phone." };
    return { ok: true as const, firstOrder: await isFirstOrder(p), discountPercent: DISCOUNT_PERCENT };
  });

async function sendTemplate(to: string, template: string, params: string[]) {
  const lk = process.env["LOVABLE_API_KEY"];
  const wk = process.env["WHATSAPP_API_KEY"];
  if (!lk || !wk || !to) { console.log("[WhatsApp dry run]", template, to || "(missing)", params); return false; }
  try {
    const r = await fetch("https://connector-gateway.lovable.dev/whatsapp/messages", {
      method: "POST",
      headers: { Authorization: `Bearer ${lk}`, "X-Connection-Api-Key": wk, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp", to, type: "template",
        template: {
          name: template, language: { code: process.env["WHATSAPP_TEMPLATE_LANG"] || "en" },
          components: [{ type: "body", parameters: params.map((text) => ({ type: "text", text })) }],
        },
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (!r.ok) { console.error("WhatsApp error", r.status, (await r.text()).slice(0, 500)); return false; }
    return true;
  } catch (e) {
    console.error("WhatsApp send failed", e);
    return false;
  }
}

export const createBooking = createServerFn({ method: "POST" })
  .inputValidator((input: BookingInput) => (input && typeof input === "object" ? input : {}) as BookingInput)
  .handler(async ({ data: body }) => {
    if (body.website) return { ok: true as const, bookingId: "LL-OK", firstOrder: false, discountPercent: 0, whatsapp: { owner: false, customer: false } };
    const today = todayIST();
    const v = validate(body, today);
    if (v.error !== null) return { ok: false as const, error: v.error };
    const d = v.data;
    const db = await admin();
    const first = await isFirstOrder(d.phone);
    const discount = first ? DISCOUNT_PERCENT : 0;
    let bookingId = "";
    for (let i = 0; i < 5; i++) {
      bookingId = newBookingId(today);
      const { error } = await db.from("bookings").insert({
        booking_id: bookingId, name: d.name, phone: d.phone, service: d.service, speed: d.speed,
        handover: d.handover, address: d.address, booking_date: d.date, slot: d.slot, bill: "below_2000",
        notes: d.notes, first_order: first, discount_percent: discount,
      });
      if (!error) break;
      if (error.code !== "23505" || i === 4) return { ok: false as const, error: "Could not book. Please call 8790774441." };
    }
    // Saved before WhatsApp is tried, so a WhatsApp problem never loses a booking.
    const msgs = buildMessages({ ...d, booking_id: bookingId, first_order: first }, DISCOUNT_PERCENT);
    const ownerTo = (process.env["OWNER_WHATSAPP"] || "918790774441").replace(/\D/g, "");
    const owner = await sendTemplate(ownerTo, process.env["WHATSAPP_TEMPLATE_OWNER"] || "luxe_new_booking_owner", msgs.owner);
    const customer = await sendTemplate("91" + d.phone, process.env["WHATSAPP_TEMPLATE_CUSTOMER"] || "luxe_booking_confirmed", msgs.customer);
    await db.from("bookings").update({ whatsapp_owner: owner, whatsapp_customer: customer }).eq("booking_id", bookingId);
    return { ok: true as const, bookingId, firstOrder: first, discountPercent: discount, whatsapp: { owner, customer } };
  });

function checkKey(key: string) {
  const expected = (process.env["ADMIN_KEY"] ?? "").trim();
  key = (key ?? "").trim();
  if (!expected || !key || key.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < key.length; i++) diff |= key.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

export const saveBilling = createServerFn({ method: "POST" })
  .inputValidator((input: { key: string; bookingId: string; items: unknown; paymentStatus: string; paymentMethod: string }) => input)
  .handler(async ({ data }) => {
    if (!checkKey(data.key)) return { ok: false as const, error: "Wrong shop key." };
    const items = validateBillingItems(data.items);
    if (!items) return { ok: false as const, error: "Add at least one item with a name, positive quantity and valid price." };
    if (!["paid", "unpaid"].includes(data.paymentStatus) || !(PAYMENT_METHODS as readonly string[]).includes(data.paymentMethod)) return { ok: false as const, error: "Choose a valid payment status and method." };
    if (data.paymentStatus === "paid" && !data.paymentMethod) return { ok: false as const, error: "Choose how the customer paid." };
    const db = await admin();
    const { data: booking, error } = await db.from("bookings").select("speed, discount_percent, paid_at").eq("booking_id", data.bookingId).maybeSingle();
    if (error || !booking) return { ok: false as const, error: "Booking not found." };
    const totals = calculateBill(items, booking.speed, booking.discount_percent);
    if (totals.total > 9999999999.99) return { ok: false as const, error: "Bill amount is too large." };
    const { error: updateError } = await db.from("bookings").update({
      billing_items: items, billing_total: totals.total, payment_status: data.paymentStatus as PaymentStatus,
      payment_method: data.paymentStatus === "paid" ? data.paymentMethod : "",
      paid_at: data.paymentStatus === "paid" ? booking.paid_at || new Date().toISOString() : null,
    }).eq("booking_id", data.bookingId);
    if (updateError) return { ok: false as const, error: "Could not save the bill. Please try again." };
    return { ok: true as const };
  });

export const createWalkIn = createServerFn({ method: 'POST' })
  .inputValidator((input: WalkInInput & { key: string }) => input)
  .handler(async ({ data }) => {
    if (!checkKey(data.key)) return { ok: false as const, error: 'Wrong shop key.' };
    const order = validateWalkIn(data);
    if (!order) return { ok: false as const, error: 'Enter valid customer details, service and date.' };
    const db = await admin();
    const existing = await db.from('bookings').select('*').eq('booking_id', order.bookingId).maybeSingle();
    if (existing.error) return { ok: false as const, error: 'Could not check this order.' };
    if (existing.data) {
      if (existing.data.order_source !== 'offline') return { ok: false as const, error: 'Order reference already exists.' };
      return { ok: true as const, booking: existing.data };
    }
    const first = await isFirstOrder(order.phone);
    const { data: booking, error } = await db.from('bookings').insert({
      booking_id: order.bookingId, name: order.name, phone: order.phone, service: order.service,
      speed: order.speed, booking_date: order.date, handover: 'drop', slot: 'Walk-in', bill: 'below_2000',
      order_source: 'offline', first_order: first, discount_percent: first ? DISCOUNT_PERCENT : 0,
    }).select('*').single();
    if (error || !booking) return { ok: false as const, error: 'Could not save walk-in order. Please retry.' };
    return { ok: true as const, booking };
  });

export const listBookings = createServerFn({ method: "POST" })
  .inputValidator((input: { key: string; status?: string | undefined; from?: string; to?: string; search?: string; source?: string }) => ({ ...input, key: String(input?.key ?? "") }))
  .handler(async ({ data }) => {
    if (!checkKey(data.key)) return { ok: false as const, error: "Wrong shop key." };
    const db = await admin();
    let q = db.from("bookings").select("*").order("id", { ascending: false }).limit(500);
    if (data.status && (BOOKING_STATUSES as readonly string[]).includes(data.status)) q = q.eq("status", data.status);
    if (data.from && /^\d{4}-\d{2}-\d{2}$/.test(data.from)) q = q.gte('booking_date', data.from);
    if (data.to && /^\d{4}-\d{2}-\d{2}$/.test(data.to)) q = q.lte('booking_date', data.to);
    if (data.source === 'online' || data.source === 'offline') q = q.eq('order_source', data.source);
    const search = String(data.search || '').trim().replace(/[^a-zA-Z0-9 -]/g, '').slice(0, 60);
    if (search) q = q.or(`name.ilike.%${search}%,phone.ilike.%${search}%,booking_id.ilike.%${search}%`);
    const { data: rows, error } = await q;
    if (error) return { ok: false as const, error: "Could not load bookings." };
    return { ok: true as const, bookings: rows };
  });

export const setBookingStatus = createServerFn({ method: "POST" })
  .inputValidator((input: { key: string; bookingId: string; status: string }) => input)
  .handler(async ({ data }) => {
    if (!checkKey(data.key)) return { ok: false as const, error: "Wrong shop key." };
    if (!(BOOKING_STATUSES as readonly string[]).includes(data.status)) return { ok: false as const, error: "Invalid status." };
    const db = await admin();
    const { error } = await db.from("bookings").update({ status: data.status as BookingStatus }).eq("booking_id", data.bookingId);
    if (error) return { ok: false as const, error: "Could not update." };
    return { ok: true as const };
  });

const STATUS_LABEL: Record<string, string> = {
  new: "Received", confirmed: "Confirmed", picked_up: "Picked up", in_process: "Being cleaned",
  ready: "Ready", delivered: "Delivered", cancelled: "Cancelled",
};

export const sendStatusToCustomer = createServerFn({ method: "POST" })
  .inputValidator((input: { key: string; bookingId: string }) => ({ key: String(input?.key ?? ""), bookingId: String(input?.bookingId ?? "") }))
  .handler(async ({ data }) => {
    if (!checkKey(data.key)) return { ok: false as const, error: "Wrong shop key." };
    const db = await admin();
    const { data: b, error } = await db.from("bookings").select("name, phone, status, booking_id").eq("booking_id", data.bookingId).maybeSingle();
    if (error || !b) return { ok: false as const, error: "Booking not found." };
    const label = STATUS_LABEL[b.status] ?? String(b.status).replace(/_/g, " ");
    const sent = await sendTemplate("91" + b.phone, "luxe_status_update", [b.name, b.booking_id, label]);
    if (!sent) return { ok: false as const, error: "WhatsApp could not send it. The status message may still be waiting for Meta's approval." };
    return { ok: true as const };
  });
