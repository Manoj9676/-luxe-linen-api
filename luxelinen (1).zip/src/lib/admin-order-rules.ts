import { clean, normPhone, SERVICES, SPEEDS } from './booking-rules';

export type OrderFilters = { from: string; to: string; search: string; source: string; status: string };
export function filterOrders<T extends { booking_date: string; booking_id: string; name: string; phone: string; order_source?: string; status: string }>(rows: T[], filters: OrderFilters): T[] {
  const search = filters.search.trim().toLowerCase();
  return rows.filter(row => (!filters.from || row.booking_date >= filters.from) && (!filters.to || row.booking_date <= filters.to) && (!filters.source || (row.order_source || 'online') === filters.source) && (!filters.status || row.status === filters.status) && (!search || `${row.booking_id} ${row.name} ${row.phone}`.toLowerCase().includes(search)));
}
export type WalkInInput = { bookingId: string; name: string; phone: string; service: string; speed: string; date: string };
export function validateWalkIn(input: WalkInInput) {
  const phone = normPhone(input.phone);
  const name = clean(input.name, 60);
  const date = new Date(`${input.date}T00:00:00Z`);
  if (!/^LL-W-[a-f0-9-]{36}$/.test(input.bookingId) || !name || !phone || !SERVICES.includes(input.service as typeof SERVICES[number]) || !SPEEDS.includes(input.speed as typeof SPEEDS[number]) || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== input.date) return null;
  return { ...input, name, phone };
}