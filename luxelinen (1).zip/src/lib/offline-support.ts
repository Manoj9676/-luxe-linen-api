export async function registerOfflineSupport() {
  if (!('serviceWorker' in navigator)) return;
  const host = window.location.hostname.toLowerCase();
  const preview = /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/.test(host.split('.')[0] || '') && /\.(lovable\.app|gpt-eng\.com|gptengineer\.run)$/.test(host);
  const development = /^project--.+-dev\.(lovable\.app|gpt-eng\.com|gptengineer\.run)$/.test(host);
  const blockedDomain = ['lovableproject.com', 'lovableproject-dev.com', 'beta.lovable.dev'].some(domain => host === domain || host.endsWith(`.${domain}`));
  if (!import.meta.env.PROD || window.self !== window.top || preview || development || blockedDomain || new URLSearchParams(window.location.search).get('sw') === 'off') {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.filter(registration => [registration.active, registration.waiting, registration.installing].some(worker => worker && new URL(worker.scriptURL).pathname === '/sw.js')).map(registration => registration.unregister()));
    return;
  }
  await navigator.serviceWorker.register('/sw.js');
}