export type BillingItem = { description: string; quantity: number; rate: number };
export type PaymentStatus = "paid" | "unpaid";
export const PAYMENT_METHODS = ["", "cash", "upi", "card", "bank_transfer"] as const;
export function calculateBill(items: BillingItem[], speed: string, discountPercent: number) {
  const subtotal = items.reduce((sum, item) => sum + Math.round(item.quantity * item.rate * 100), 0);
  const charge = subtotal * (speed === "Express" ? 2 : 1);
  const discount = Math.round(charge * discountPercent / 100);
  return { subtotal: subtotal / 100, charge: charge / 100, discount: discount / 100, total: (charge - discount) / 100 };
}
export function validateBillingItems(input: unknown): BillingItem[] | null {
  if (!Array.isArray(input) || input.length < 1 || input.length > 100) return null;
  const items: BillingItem[] = [];
  for (const row of input) {
    if (!row || typeof row !== "object") return null;
    const description = typeof row.description === "string" ? row.description.trim().slice(0, 120) : "";
    const quantity = row.quantity;
    const rate = row.rate;
    if (!description || typeof quantity !== "number" || !Number.isFinite(quantity) || quantity <= 0 || quantity > 10000 || typeof rate !== "number" || !Number.isFinite(rate) || rate < 0 || rate > 1000000 || Math.round(rate * 100) !== rate * 100 && Math.abs(Math.round(rate * 100) - rate * 100) > 0.00001) return null;
    items.push({ description, quantity, rate });
  }
  return items;
}