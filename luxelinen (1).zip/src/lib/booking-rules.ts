// Booking rules ported from the original backend (services/bookings.py). Pure, no server imports.
export const SERVICES = ["Laundry", "Dryclean", "Ironing", "Home linen", "Curtains"] as const;
export const SPEEDS = ["Regular", "Express"] as const;
export const HANDOVER = ["pickup", "drop"] as const;
// Keep the same as WEEK / SUN in src/site/luxe-site.ts
export const SLOTS_WEEK = ["9 AM to 12 PM", "2 PM to 5 PM", "5 PM to 8 PM"];
export const SLOTS_SUN = ["11 AM to 1 PM", "2 PM to 6 PM"];
export const BOOKING_STATUSES = ["new", "confirmed", "picked_up", "in_process", "ready", "delivered", "cancelled"] as const;
export type BookingStatus = (typeof BOOKING_STATUSES)[number];
export const DISCOUNT_PERCENT = 30;

const ID_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function clean(value: unknown, maxLen: number): string {
  const s = value == null ? "" : String(value);
  return s.replace(/[\x00-\x1f\x7f]+/g, " ").replace(/\s{2,}/g, " ").trim().slice(0, maxLen);
}

export function normPhone(value: unknown): string | null {
  let d = String(value ?? "").replace(/\D/g, "");
  if (d.length === 12 && d.startsWith("91")) d = d.slice(2);
  else if (d.length === 11 && d.startsWith("0")) d = d.slice(1);
  return /^[6-9]\d{9}$/.test(d) ? d : null;
}

/** Today's date in India as YYYY-MM-DD */
export function todayIST(now = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(now);
}

function parseISO(s: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const [y = 0, m = 0, d = 0] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d ? dt : null;
}

export function newBookingId(today: string): string {
  let s = "";
  const r = crypto.getRandomValues(new Uint32Array(4));
  for (let i = 0; i < 4; i++) s += ID_ALPHABET[(r[i] ?? 0) % ID_ALPHABET.length];
  return `LL-${today.slice(2, 4)}${today.slice(5, 7)}${today.slice(8, 10)}-${s}`;
}

export type CleanBooking = {
  name: string; phone: string; service: string; speed: string; handover: "pickup" | "drop";
  address: string; date: string; slot: string; notes: string;
};

export type BookingInput = { name?: unknown; phone?: unknown; service?: unknown; speed?: unknown; handover?: unknown; address?: unknown; date?: unknown; slot?: unknown; notes?: unknown; website?: unknown };

export function validate(body: BookingInput, today: string):
  { data: CleanBooking; error: null } | { data: null; error: string } {
  const fail = (error: string) => ({ data: null, error }) as const;
  const phone = normPhone(body.phone);
  const name = clean(body.name, 60);
  const pick = <T extends readonly string[]>(v: unknown, list: T) => (list.includes(v as string) ? (v as T[number]) : null);
  const service = pick(body.service, SERVICES);
  const speed = pick(body.speed, SPEEDS);
  const handover = pick(body.handover, HANDOVER);
  const address = clean(body.address, 300);
  const notes = clean(body.notes, 200);

  if (!name) return fail("Enter your name.");
  if (!phone) return fail("Enter a valid 10-digit mobile number.");
  if (!service || !speed || !handover) return fail("Choose a service, speed and how you will hand over.");
  if (handover === "pickup" && address.length < 10) return fail("Enter your full address.");
  const rawDate = String(body.date ?? "");
  const d = parseISO(rawDate);
  const t = parseISO(today)!;
  if (!d) return fail("Choose a date.");
  const days = Math.round((d.getTime() - t.getTime()) / 86400000);
  if (days < 0 || days > 60) return fail("Choose a date within the next 60 days.");
  const wd = d.getUTCDay();
  if (wd === 1) return fail("We are closed on Mondays. Choose another date.");
  const slots = wd === 0 ? SLOTS_SUN : SLOTS_WEEK;
  if (!slots.includes(body.slot as string)) return fail("Choose a valid time slot.");
  return { data: { name, phone, service, speed, handover, address, date: rawDate, slot: body.slot as string, notes }, error: null };
}

function param(v: unknown) {
  return clean(v, 300).replace(/\s+/g, " ") || "-";
}

export function buildMessages(b: CleanBooking & { booking_id: string; first_order: boolean }, discount: number) {
  const svc = `${b.service} (${b.speed})`;
  const when = (b.handover === "pickup" ? "Pickup " : "Drop at shop ") + `${b.date}, ${b.slot}`;
  const offer = b.first_order ? `FIRST ORDER, give ${discount}% off`
    : "None";
  const owner = [b.booking_id, b.name, "+91" + b.phone, svc, when,
    b.handover === "pickup" ? b.address : "Customer will drop at shop", offer, b.notes || "None"];
  const customer = [b.name, b.booking_id, svc, `${b.date}, ${b.slot}`,
    b.first_order ? `Your first-order ${discount}% off will be applied to your bill.` : "Pickup and drop is free within 2 km."];
  return { owner: owner.map(param), customer: customer.map(param) };
}
