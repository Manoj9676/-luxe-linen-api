import { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { SERVICES, SPEEDS, todayIST } from '@/lib/booking-rules';
import { validateWalkIn, type WalkInInput } from '@/lib/admin-order-rules';

export function WalkInOrder({ onClose, onCreate }: { onClose: () => void; onCreate: (input: WalkInInput) => Promise<void> }) {
  const [name, setName] = useState(''); const [phone, setPhone] = useState('');
  const [service, setService] = useState('Laundry'); const [speed, setSpeed] = useState('Regular');
  const [date, setDate] = useState(todayIST()); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  const inputClass = 'w-full rounded-md border border-input bg-background px-3 py-2';
  return <Dialog open onOpenChange={open => { if (!open && !busy) onClose(); }}><DialogContent><DialogHeader><DialogTitle>New walk-in order</DialogTitle><DialogDescription>Customer details</DialogDescription></DialogHeader>
    <form className="grid gap-4" onSubmit={async event => {
      event.preventDefault(); const input = validateWalkIn({ bookingId: `LL-W-${crypto.randomUUID()}`, name, phone, service, speed, date });
      if (!input) { setError('Enter a valid name, mobile number and date.'); return; }
      setBusy(true); try { await onCreate(input); } catch { setError('Could not create order. Please retry.'); } finally { setBusy(false); }
    }}>
      <label>Customer name<input className={inputClass} aria-label="Customer name" required maxLength={60} value={name} onChange={e => setName(e.target.value)} /></label>
      <label>Mobile number<input className={inputClass} aria-label="Mobile number" type="tel" required value={phone} onChange={e => setPhone(e.target.value)} /></label>
      <label>Order date<input className={inputClass} aria-label="Order date" type="date" required value={date} onChange={e => setDate(e.target.value)} /></label>
      <div className="grid grid-cols-2 gap-3"><label>Service<select className={inputClass} value={service} onChange={e => setService(e.target.value)}>{SERVICES.map(s => <option key={s}>{s}</option>)}</select></label><label>Speed<select className={inputClass} value={speed} onChange={e => setSpeed(e.target.value)}>{SPEEDS.map(s => <option key={s}>{s}</option>)}</select></label></div>
      {error && <p role="alert" className="text-destructive">{error}</p>}
      <Button disabled={busy} type="submit">{busy ? 'Creating…' : 'Prepare bill'}</Button>
    </form></DialogContent></Dialog>;
}