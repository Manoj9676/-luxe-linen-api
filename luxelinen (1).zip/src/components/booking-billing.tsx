import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Trash2, Save, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { calculateBill, type BillingItem } from "@/lib/billing-rules";
import { saveBilling } from "@/lib/bookings.functions";

export type BillBooking = { booking_id: string; name: string; speed: string; discount_percent: number; billing_items: unknown; billing_total: number; payment_status: string; payment_method: string };
export const money = (amount: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(amount);
export type BillSave = { items: BillingItem[]; paymentStatus: string; paymentMethod: string };
export function BookingBilling({ booking, shopKey, onClose, onSaved, onSave, localDraft }: { booking: BillBooking; shopKey: string; onClose: () => void; onSaved: () => Promise<void>; onSave?: (bill: BillSave) => Promise<string | null>; localDraft?: boolean }) {
  const save = useServerFn(saveBilling);
  const [items, setItems] = useState<BillingItem[]>(Array.isArray(booking.billing_items) && booking.billing_items.length ? booking.billing_items : [{ description: "", quantity: 1, rate: 0 }]);
  const [status, setStatus] = useState(booking.payment_status || "unpaid");
  const [method, setMethod] = useState(booking.payment_method || "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const totals = calculateBill(items, booking.speed, booking.discount_percent);
  const update = (index: number, change: Partial<BillingItem>) => setItems((rows) => rows.map((row, i) => i === index ? { ...row, ...change } : row));
  const inputClass = "w-full min-w-0 rounded-md border border-input bg-background px-2 py-2 text-sm";
  return <Dialog open onOpenChange={(open) => { if (!open && !busy) onClose(); }}>
    <DialogContent className="max-h-[90dvh] w-[calc(100%-2rem)] max-w-2xl overflow-y-auto">
      <DialogHeader><DialogTitle className="flex items-center gap-2"><Receipt className="size-5" />Customer bill</DialogTitle><DialogDescription className="break-words">{booking.name} · {booking.booking_id}</DialogDescription></DialogHeader>
      <form className="space-y-5" onSubmit={async (event) => {
        event.preventDefault(); setBusy(true); setError("");
        try {
          if (onSave) {
            const problem = await onSave({ items, paymentStatus: status, paymentMethod: method });
            if (problem) setError(problem); else onClose();
            return;
          }
          const result = await save({ data: { key: shopKey, bookingId: booking.booking_id, items, paymentStatus: status, paymentMethod: method } });
          if (!result.ok) setError(result.error);
          else { await onSaved(); onClose(); }
        } catch { setError("Could not save the bill. Please try again."); }
        finally { setBusy(false); }
      }}>
        <fieldset disabled={busy} className="space-y-3">
          {items.map((item, i) => <div key={i} className="grid grid-cols-[1fr_1fr_2.25rem] items-end gap-2 sm:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_2.25rem]">
            <label className="col-span-3 text-xs sm:col-span-1">Item<input aria-label={`Item ${i + 1}`} className={inputClass} required maxLength={120} value={item.description} onChange={(e) => update(i, { description: e.target.value })} /></label>
            <label className="text-xs">Quantity<input aria-label={`Quantity ${i + 1}`} className={inputClass} type="number" min="0.01" max="10000" step="0.01" required value={item.quantity} onChange={(e) => update(i, { quantity: Number(e.target.value) })} /></label>
            <label className="text-xs">Regular rate (₹)<input aria-label={`Rate ${i + 1}`} className={inputClass} type="number" min="0" max="1000000" step="0.01" required value={item.rate} onChange={(e) => update(i, { rate: Number(e.target.value) })} /></label>
            <Button type="button" variant="ghost" size="icon" title="Remove item" aria-label={`Remove item ${i + 1}`} disabled={items.length === 1} onClick={() => setItems((rows) => rows.filter((_, index) => index !== i))}><Trash2 /></Button>
          </div>)}
          <Button type="button" variant="outline" size="sm" disabled={items.length >= 100} onClick={() => setItems((rows) => [...rows, { description: "", quantity: 1, rate: 0 }])}><Plus />Add item</Button>
          <dl className="space-y-2 border-y border-border py-4 text-sm">
            {localDraft && <p className="text-muted-foreground">Draft · first-order discount confirmed when synced</p>}
            <div className="flex justify-between"><dt>Regular subtotal</dt><dd>{money(totals.subtotal)}</dd></div>
            {booking.speed === "Express" && <div className="flex justify-between"><dt>Express (double charge)</dt><dd>{money(totals.charge)}</dd></div>}
            {booking.discount_percent > 0 && <div className="flex justify-between"><dt>First-order discount ({booking.discount_percent}%)</dt><dd>−{money(totals.discount)}</dd></div>}
            <div className="flex justify-between text-lg font-semibold"><dt>Total</dt><dd>{money(totals.total)}</dd></div>
          </dl>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="text-sm">Payment status<select aria-label="Payment status" className={inputClass} value={status} onChange={(e) => setStatus(e.target.value)}><option value="unpaid">Unpaid</option><option value="paid">Paid</option></select></label>
            {status === "paid" && <label className="text-sm">Payment method<select aria-label="Payment method" className={inputClass} required value={method} onChange={(e) => setMethod(e.target.value)}><option value="">Choose method</option><option value="cash">Cash</option><option value="upi">UPI</option><option value="card">Card</option><option value="bank_transfer">Bank transfer</option></select></label>}
          </div>
        </fieldset>
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        <div className="flex justify-end gap-2"><Button type="button" variant="outline" disabled={busy} onClick={onClose}>Cancel</Button><Button type="submit" disabled={busy}><Save />{busy ? "Saving…" : "Save bill"}</Button></div>
      </form>
    </DialogContent>
  </Dialog>;
}