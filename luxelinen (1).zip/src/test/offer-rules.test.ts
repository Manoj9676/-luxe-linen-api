import { describe, it, expect } from "vitest";
import { DISCOUNT_PERCENT, buildMessages } from "@/lib/booking-rules";

describe("offer rules", () => {
  it("first order discount is 30%", () => {
    expect(DISCOUNT_PERCENT).toBe(30);
  });
  it("returning customers are told pickup is free within 2 km", () => {
    const m = buildMessages({ name: "A", phone: "9000000001", service: "Laundry", speed: "Regular", handover: "drop", address: "", date: "2026-11-20", slot: "10am", notes: "", booking_id: "LL-1", first_order: false } as any, DISCOUNT_PERCENT);
    expect(m.customer.join(" ")).toContain("free within 2 km");
  });
});
