import { describe, expect, it } from "vitest";
import { normPhone, validate, newBookingId } from "@/lib/booking-rules";

const base = { name: "Asha", phone: "9876543210", service: "Laundry", speed: "Regular", handover: "drop", slot: "9 AM to 12 PM" };
// 2026-11-01 is a Sunday
const today = "2026-11-01";

describe("booking rules", () => {
  it("normalises +91 and leading 0 phone numbers", () => {
    expect(normPhone("+91 98765 43210")).toBe("9876543210");
    expect(normPhone("09876543210")).toBe("9876543210");
    expect(normPhone("1234567890")).toBeNull();
  });
  it("rejects Mondays", () => {
    expect(validate({ ...base, date: "2026-11-02" }, today).error).toBe("We are closed on Mondays. Choose another date.");
  });
  it("uses Sunday slots on Sundays", () => {
    expect(validate({ ...base, date: "2026-11-08" }, today).error).toBe("Choose a valid time slot.");
    expect(validate({ ...base, date: "2026-11-08", slot: "11 AM to 1 PM" }, today).error).toBeNull();
  });
  it("rejects dates more than 60 days ahead", () => {
    expect(validate({ ...base, date: "2027-01-05" }, today).error).toBe("Choose a date within the next 60 days.");
  });
  it("requires an address for pickup", () => {
    expect(validate({ ...base, handover: "pickup", address: "short", date: "2026-11-03" }, today).error).toBe("Enter your full address.");
  });
  it("builds booking ids from the date", () => {
    expect(newBookingId(today)).toMatch(/^LL-261101-[A-Z2-9]{4}$/);
  });
});
