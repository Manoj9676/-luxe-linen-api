import { describe, it, expect } from "vitest";
import { calculateBill, validateBillingItems } from "@/lib/billing-rules";
const items = [{ description: "Shirt", quantity: 2, rate: 100 }];
describe("billing", () => {
  it("calculates item quantities and prices", () => expect(calculateBill(items, "Regular", 0).total).toBe(200));
  it("applies the 30% first-order discount", () => expect(calculateBill(items, "Regular", 30).total).toBe(140));
  it("doubles express charges", () => expect(calculateBill(items, "Express", 0).total).toBe(400));
  it("discounts the express charge", () => expect(calculateBill(items, "Express", 30).total).toBe(280));
  it("rejects negative prices", () => expect(validateBillingItems([{ ...items[0], rate: -1 }])).toBeNull());
  it("rejects zero quantity", () => expect(validateBillingItems([{ ...items[0], quantity: 0 }])).toBeNull());
  it("rejects empty bills", () => expect(validateBillingItems([])).toBeNull());
  it("rounds money to paise", () => expect(calculateBill([{ description: "Linen", quantity: 1.5, rate: 10.01 }], "Regular", 0).total).toBe(15.02));
});