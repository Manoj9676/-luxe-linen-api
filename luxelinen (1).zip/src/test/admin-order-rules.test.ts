import { describe, it, expect } from 'vitest';
import { filterOrders, validateWalkIn } from '../lib/admin-order-rules';
const rows = [
  { booking_id: 'LL-1', booking_date: '2026-11-15', name: 'Manoj', phone: '9676510373', status: 'new', order_source: 'online' },
  { booking_id: 'LL-2', booking_date: '2026-11-16', name: 'Anita', phone: '9876543210', status: 'paid', order_source: 'offline' },
  { booking_id: 'LL-3', booking_date: '2026-11-17', name: 'Manoj', phone: '9676510373', status: 'new', order_source: 'online' },
];
const filters = { from: '', to: '', search: '', source: '', status: '' };
describe('Admin order tools', () => {
  it('includes both date boundaries and excludes later orders', () => expect(filterOrders(rows, { ...filters, from: '2026-11-15', to: '2026-11-16' }).map(r => r.booking_id)).toEqual(['LL-1', 'LL-2']));
  it('searches customer name case-insensitively', () => expect(filterOrders(rows, { ...filters, search: 'MANOJ' }).length).toBe(2));
  it('searches mobile numbers', () => expect(filterOrders(rows, { ...filters, search: '987654' })[0]?.booking_id).toBe('LL-2'));
  it('searches booking references', () => expect(filterOrders(rows, { ...filters, search: 'LL-3' })[0]?.booking_id).toBe('LL-3'));
  it('separates walk-in orders from website orders', () => expect(filterOrders(rows, { ...filters, source: 'offline' }).map(r => r.booking_id)).toEqual(['LL-2']));
  it('rejects invalid walk-in dates', () => expect(validateWalkIn({ bookingId: 'LL-W-12345678-1234-1234-1234-123456789abc', name: 'Manoj', phone: '9676510373', service: 'Laundry', speed: 'Regular', date: '2026-02-30' })).toBeNull());
});