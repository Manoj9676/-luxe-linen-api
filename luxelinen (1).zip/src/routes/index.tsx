import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import bodyHtml from "@/site/body.html?raw";
import luxeCss from "@/site/luxe.css?url";
import { checkFirstOrder, createBooking } from "@/lib/bookings.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Luxe Linen – Laundry & Dryclean in Tellapur, Hyderabad" },
      { name: "description", content: "Premium laundry, dryclean, steam ironing, home linen and curtains. Book a pickup online: 15% off your first order." },
      { property: "og:title", content: "Luxe Linen – Laundry & Dryclean" },
      { property: "og:description", content: "Premium care for every fabric. Book a pickup online: 15% off your first order." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Jost:wght@400;500;600&display=swap" },
      { rel: "stylesheet", href: luxeCss },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    let cleanup: (() => void) | undefined;
    import("@/site/luxe-site").then((m) => {
      cleanup = m.initLuxeSite({ checkFirstOrder, createBooking });
    });
    return () => cleanup?.();
  }, []);
  return <div className="luxe-root" dangerouslySetInnerHTML={{ __html: bodyHtml }} />;
}
