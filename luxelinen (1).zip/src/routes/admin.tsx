import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { listBookings, sendStatusToCustomer, setBookingStatus, createWalkIn, saveBilling } from "@/lib/bookings.functions";
import { BOOKING_STATUSES } from "@/lib/booking-rules";
import { BookingBilling, money, type BillSave } from "@/components/booking-billing";
import { WalkInOrder } from '@/components/walk-in-order';
import { filterOrders, type WalkInInput } from '@/lib/admin-order-rules';
import { calculateBill } from '@/lib/billing-rules';
import { Button } from "@/components/ui/button";
import { Receipt, Plus, Search, RefreshCw, Lock, CloudUpload } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Bookings – Luxe Linen shop" },
      { name: "description", content: "Luxe Linen shop view of website bookings." },
      { property: "og:title", content: "Bookings – Luxe Linen shop" },
      { property: "og:description", content: "Luxe Linen shop view of website bookings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

type Row = {
  order_source?: string; localInput?: WalkInInput;
  booking_id: string; name: string; phone: string; service: string; speed: string; handover: string;
  address: string | null; booking_date: string; slot: string; bill: string; notes: string | null;
  first_order: boolean; discount_percent: number; status: string; whatsapp_owner: boolean;
  whatsapp_customer: boolean; created_at: string;
  billing_items: unknown; billing_total: number; payment_status: string; payment_method: string;
};

function Admin() {
  const create = useServerFn(createWalkIn);
  const saveBill = useServerFn(saveBilling);
  const list = useServerFn(listBookings);
  const setStatus = useServerFn(setBookingStatus);
  const sendStatus = useServerFn(sendStatusToCustomer);
  const [sending, setSending] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [key, setKey] = useState("");
  const [saved, setSaved] = useState<string | null>(null);
  const [filter, setFilter] = useState("");
  const [rows, setRows] = useState<Row[] | null>(null);
  const [err, setErr] = useState("");
  const [billingBooking, setBillingBooking] = useState<Row | null>(null);
  const [from, setFrom] = useState(''); const [to, setTo] = useState('');
  const [search, setSearch] = useState(''); const [source, setSource] = useState('');
  const [online, setOnline] = useState(true); const [walkIn, setWalkIn] = useState(false);
  const [drafts, setDrafts] = useState<Row[]>([]); const [syncing, setSyncing] = useState(false);
  function storeDrafts(next: Row[]) { localStorage.setItem('ll-bill-drafts', JSON.stringify(next)); setDrafts(next); }
  useEffect(() => {
    setOnline(navigator.onLine);
    try {
      setDrafts(JSON.parse(localStorage.getItem('ll-bill-drafts') || '[]'));
      const cached = sessionStorage.getItem('ll-admin-rows'); if (cached) setRows(JSON.parse(cached));
    } catch { /* Ignore malformed device storage. */ }
    const connected = () => setOnline(true); const disconnected = () => setOnline(false);
    window.addEventListener('online', connected); window.addEventListener('offline', disconnected);
    return () => { window.removeEventListener('online', connected); window.removeEventListener('offline', disconnected); };
  }, []);

  useEffect(() => { setSaved(sessionStorage.getItem("ll-admin-key")); }, []);

  async function load(k: string, status = filter) {
    setErr("");
    if (!navigator.onLine) { setNote('Offline · showing orders saved in this tab'); return; }
    try {
      const r = await list({ data: { key: k, status: status || undefined, from, to, search, source } });
      if (!r.ok) { setErr(r.error); if (r.error === 'Wrong shop key.') { setRows(null); sessionStorage.removeItem('ll-admin-key'); sessionStorage.removeItem('ll-admin-rows'); setSaved(null); } return; }
      sessionStorage.setItem("ll-admin-key", k); sessionStorage.setItem('ll-admin-rows', JSON.stringify(r.bookings)); setSaved(k); setRows(r.bookings as Row[]);
    } catch { setErr('Could not connect. Saved orders and bill drafts are still available.'); }
  }
  useEffect(() => { if (saved) load(saved); }, [saved === null]); // eslint-disable-line react-hooks/exhaustive-deps

  async function syncDrafts() {
    if (!saved || !online) return;
    setSyncing(true); setErr('');
    let remaining = [...drafts];
    try {
      for (const draft of drafts) {
        if (draft.localInput) {
          const created = await create({ data: { ...draft.localInput, key: saved } });
          if (!created.ok) { setErr(created.error); break; }
        }
        if (Array.isArray(draft.billing_items) && draft.billing_items.length) {
          const result = await saveBill({ data: { key: saved, bookingId: draft.booking_id, items: draft.billing_items, paymentStatus: draft.payment_status, paymentMethod: draft.payment_method } });
          if (!result.ok) { setErr(result.error); break; }
        }
        remaining = remaining.filter(row => row.booking_id !== draft.booking_id); storeDrafts(remaining);
      }
      await load(saved); setNote(remaining.length ? `${remaining.length} drafts still waiting to sync.` : 'All bill drafts synced.');
    } catch { setErr('Sync interrupted. Unsynced drafts remain on this device.'); }
    finally { setSyncing(false); }
  }
  const allRows = [...drafts, ...(rows || []).filter(row => !drafts.some(draft => draft.booking_id === row.booking_id))];
  const visibleRows = filterOrders(allRows, { from, to, search, source, status: filter });

  if (!saved) {
    return (
      <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center gap-4 p-6">
        <h1 className="text-2xl font-semibold">Luxe Linen bookings</h1>
        <form className="flex flex-col gap-3" onSubmit={(e) => { e.preventDefault(); load(key.trim()); }}>
          <label className="flex flex-col gap-1 text-sm">Shop key
            <input type="password" autoCapitalize="none" autoCorrect="off" autoComplete="current-password" spellCheck={false} className="rounded-md border border-input bg-background px-3 py-2" value={key} onChange={(e) => setKey(e.target.value)} />
          </label>
          <Button type="submit">Open</Button>
          {err && <p className="text-sm text-destructive">{err}</p>}
        </form>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-6xl p-6">
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <h1 className="mr-auto text-2xl font-semibold">Bookings</h1>
        <select className="rounded-md border border-input bg-background px-3 py-2 text-sm" value={filter}
          onChange={(e) => { setFilter(e.target.value); load(saved, e.target.value); }}>
          <option value="">All statuses</option>
          {BOOKING_STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
        </select>
        <Button variant="outline" disabled={!online} onClick={() => load(saved)}><RefreshCw />Refresh</Button>
        <Button onClick={() => setWalkIn(true)} disabled={syncing}><Plus />Walk-in order</Button>
        <Button variant="outline" onClick={() => { sessionStorage.removeItem("ll-admin-key"); sessionStorage.removeItem('ll-admin-rows'); localStorage.removeItem('ll-bill-drafts'); setDrafts([]); setSaved(null); setRows(null); }}><Lock />Lock</Button>
      </div>
      <form className="mb-4 flex flex-wrap items-end gap-3 border-y border-border py-4" onSubmit={e => { e.preventDefault(); if (from && to && from > to) { setErr('From date must be before or equal to To date.'); return; } load(saved); }}>
        <label className="grid gap-1 text-sm">From date<input aria-label="From date" type="date" className="min-w-0 rounded-md border border-input bg-background px-3 py-2" value={from} onChange={e => setFrom(e.target.value)} /></label>
        <label className="grid gap-1 text-sm">To date<input aria-label="To date" type="date" className="min-w-0 rounded-md border border-input bg-background px-3 py-2" value={to} onChange={e => setTo(e.target.value)} /></label>
        <label className="grid min-w-0 flex-1 gap-1 text-sm">Search<input aria-label="Search orders" placeholder="Name, phone or booking ID" className="w-full rounded-md border border-input bg-background px-3 py-2" value={search} onChange={e => setSearch(e.target.value)} /></label>
        <select aria-label="Order source" className="rounded-md border border-input bg-background px-3 py-2 text-sm" value={source} onChange={e => setSource(e.target.value)}><option value="">All orders</option><option value="online">Website orders</option><option value="offline">Walk-in orders</option></select>
        <Button type="submit" variant="outline"><Search />Apply</Button>
      </form>
      <div className="mb-4 flex flex-wrap items-center gap-3 text-sm"><span className="rounded px-2 py-1 bg-order-online text-order-online-foreground">Website orders</span><span className="rounded px-2 py-1 bg-order-offline text-order-offline-foreground">Walk-in orders</span><span className="text-muted-foreground">{online ? 'Connected' : 'Offline'} · {visibleRows.length} orders</span>{drafts.length > 0 && <Button variant="outline" size="sm" disabled={!online || syncing} onClick={syncDrafts}><CloudUpload />{syncing ? 'Syncing…' : `Sync ${drafts.length} drafts`}</Button>}</div>
      {note && <p className="mb-3 text-sm text-primary">{note}</p>}
      {err && <p className="mb-3 text-sm text-destructive">{err}</p>}
      {rows === null && !drafts.length ? <p className="text-muted-foreground">{online ? 'Loading…' : 'No saved orders in this tab.'}</p> : visibleRows.length === 0 ? <p className="text-muted-foreground">No matching orders.</p> : (
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full text-left text-sm">
            <thead className="bg-muted text-muted-foreground">
               <tr>{["Booking", "Customer", "Service", "When", "Offer", "WhatsApp", "Status", "Billing"].map((h) => <th key={h} className="px-3 py-2 font-medium">{h}</th>)}</tr>
            </thead>
            <tbody>
              {visibleRows.map((b) => (
                <tr key={b.booking_id} className={`border-t border-border align-top ${b.order_source === 'offline' ? 'bg-order-offline' : 'bg-order-online'}`}>
                  <td className="max-w-48 break-words px-3 py-2 font-mono text-xs">{b.booking_id}<div className="text-muted-foreground">{new Date(b.created_at).toLocaleString("en-IN")}</div><div>{b.order_source === 'offline' ? 'Walk-in' : 'Website'}{drafts.some(d => d.booking_id === b.booking_id) ? ' · Unsynced draft' : ''}</div></td>
                  <td className="px-3 py-2">{b.name}<div><a className="underline" href={`tel:${b.phone}`}>{b.phone}</a></div>{b.address && <div className="text-muted-foreground">{b.address}</div>}{b.notes && <div className="italic text-muted-foreground">{b.notes}</div>}</td>
                  <td className="px-3 py-2">{b.service} ({b.speed})</td>
                  <td className="px-3 py-2">{b.handover === "pickup" ? "Pickup" : "Drop at shop"}<div>{b.booking_date}, {b.slot}</div></td>
                  <td className="px-3 py-2">{b.first_order ? `First order ${b.discount_percent}% off` : "—"}</td>
                  <td className="px-3 py-2 text-xs">Shop: {b.whatsapp_owner ? "sent" : "not sent"}<br />Customer: {b.whatsapp_customer ? "sent" : "not sent"}</td>
                  <td className="px-3 py-2">
                    <select disabled={!online || !!b.localInput || syncing} className="rounded-md border border-input bg-background px-2 py-1" value={b.status}
                      onChange={async (e) => {
                        const status = e.target.value;
                        const r = await setStatus({ data: { key: saved, bookingId: b.booking_id, status } });
                        if (!r.ok) setErr(r.error);
                        else setRows((rs) => rs?.map((x) => (x.booking_id === b.booking_id ? { ...x, status } : x)) ?? null);
                      }}>
                      {BOOKING_STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
                    </select>
                    <Button variant="outline" size="sm" className="mt-2 h-auto whitespace-normal text-xs" disabled={!online || !!b.localInput || sending === b.booking_id}
                      onClick={async () => {
                        setErr(""); setNote(""); setSending(b.booking_id);
                        try {
                          const r = await sendStatus({ data: { key: saved, bookingId: b.booking_id } });
                          if (r.ok) setNote(`Status sent to ${b.name} on WhatsApp.`); else setErr(r.error);
                        } catch { setErr("Could not send. Please try again."); }
                        setSending(null);
                      }}>{sending === b.booking_id ? "Sending…" : "Send status on WhatsApp"}</Button>
                  </td>
                   <td className="px-3 py-2">
                     {Array.isArray(b.billing_items) && b.billing_items.length > 0 ? <><div className="font-medium">{money(Number(b.billing_total))}</div><div className="mb-2 text-xs text-muted-foreground">{b.payment_status === "paid" ? "Paid" : "Unpaid"}{b.payment_status === "paid" && b.payment_method ? ` · ${b.payment_method.replace("_", " ").toUpperCase()}` : ""}</div></> : <div className="mb-2 text-xs text-muted-foreground">No bill</div>}
                      <Button disabled={syncing} size="sm" variant="outline" onClick={() => setBillingBooking(b)}><Receipt />{Array.isArray(b.billing_items) && b.billing_items.length ? "Edit bill" : "Create bill"}</Button>
                   </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {walkIn && <WalkInOrder onClose={() => setWalkIn(false)} onCreate={async input => {
        if (online) {
          const result = await create({ data: { ...input, key: saved } });
          if (!result.ok) { setErr(result.error); return; }
          setWalkIn(false); await load(saved); setBillingBooking(result.booking as Row); return;
        }
        const row: Row = { booking_id: input.bookingId, name: input.name, phone: input.phone, service: input.service, speed: input.speed, handover: 'drop', address: '', booking_date: input.date, slot: 'Walk-in', bill: '', notes: '', first_order: false, discount_percent: 0, status: 'new', whatsapp_owner: false, whatsapp_customer: false, created_at: new Date().toISOString(), billing_items: [], billing_total: 0, payment_status: 'unpaid', payment_method: '', order_source: 'offline', localInput: input };
        storeDrafts([...drafts, row]); setWalkIn(false); setBillingBooking(row);
      }} />}
      {billingBooking && <BookingBilling booking={billingBooking} shopKey={saved} localDraft={!!billingBooking.localInput} onClose={() => setBillingBooking(null)} onSaved={() => load(saved)} onSave={async (bill: BillSave) => {
        if (online && !billingBooking.localInput) {
          const result = await saveBill({ data: { key: saved, bookingId: billingBooking.booking_id, ...bill } });
          if (!result.ok) return result.error;
          storeDrafts(drafts.filter(d => d.booking_id !== billingBooking.booking_id)); await load(saved); return null;
        }
        const draft = { ...billingBooking, billing_items: bill.items, billing_total: calculateBill(bill.items, billingBooking.speed, billingBooking.discount_percent).total, payment_status: bill.paymentStatus, payment_method: bill.paymentMethod };
        storeDrafts([...drafts.filter(d => d.booking_id !== draft.booking_id), draft]); setNote('Bill draft saved on this device. Sync when connected.'); return null;
      }} />}
    </main>
  );
}
