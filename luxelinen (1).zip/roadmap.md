# Billing
- [x] Add saved itemised bills and payment tracking to admin bookings.
- [x] Test calculation rules and verify the shop billing flow.

# Admin order tools
- [ ] Add inclusive date filters, search, and order-source colours.
- [ ] Add walk-in orders and offline bill drafts with manual sync.
- [ ] Add guarded published-app offline support and verify flows.